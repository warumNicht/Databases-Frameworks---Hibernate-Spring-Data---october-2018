create function udf_count_colonists_by_destination_planet(planet_name varchar(30))
  returns int
  BEGIN

RETURN (SELECT COUNT(DISTINCT(t.colonist_id))
FROM planets AS p
JOIN spaceports AS sp ON p.id=sp.planet_id
JOIN journeys AS j ON sp.id=j.destination_spaceport_id
JOIN travel_cards AS t ON j.id=t.journey_id
WHERE p.name=planet_name);
END;

