create procedure udp_get_book_count_by_author(IN first_name varchar(255), IN last_name varchar(255), OUT result int)
  BEGIN

SET result := (SELECT COUNT(b.id)
FROM authors AS a
LEFT JOIN books AS b ON a.id=b.author_id
WHERE a.first_name=first_name AND a.last_name=last_name
GROUP BY a.id);


END;

