create procedure usp_customers_with_unexpired_loans(IN cust_id int)
  BEGIN
  SELECT c.customer_id,c.first_name,l.loan_id
FROM customers AS c
JOIN loans AS l ON c.customer_id=l.customer_id
WHERE ISNULL(l.expiration_date) AND c.customer_id=cust_id;

END;

