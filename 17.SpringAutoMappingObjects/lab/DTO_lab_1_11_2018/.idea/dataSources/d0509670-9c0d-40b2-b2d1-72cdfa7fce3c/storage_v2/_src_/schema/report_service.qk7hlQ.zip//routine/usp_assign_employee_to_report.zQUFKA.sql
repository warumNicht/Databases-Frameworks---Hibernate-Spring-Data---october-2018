create procedure usp_assign_employee_to_report(IN employee_id int, IN report_id int)
  BEGIN
 		 IF (SELECT e.department_id
FROM employees AS e
WHERE e.id=employee_id)  !=   (SELECT c.department_id
FROM reports AS r
JOIN categories AS c ON r.category_id=c.id
WHERE r.id=report_id
GROUP BY r.id)
    
     	THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Employee doesn\'t belong to the appropriate department!';
    END IF;  
	 
	 UPDATE reports AS r
	 SET r.employee_id=employee_id
	 WHERE r.id=report_id;

END;

