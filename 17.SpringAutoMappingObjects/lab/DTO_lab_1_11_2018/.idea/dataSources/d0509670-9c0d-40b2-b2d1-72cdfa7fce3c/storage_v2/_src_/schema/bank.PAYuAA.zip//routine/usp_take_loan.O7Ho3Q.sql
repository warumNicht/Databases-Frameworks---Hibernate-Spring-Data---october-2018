create procedure usp_take_loan(IN cust_id    int, IN loan_amount decimal(18, 2), IN interest decimal(4, 2),
                               IN start_date date)
  BEGIN

 		 IF (loan_amount NOT BETWEEN 0.01 AND 100000)
    
     	THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Invalid Loan Amount.';
    END IF; 
    
    INSERT INTO loans(start_date,amount,interest,customer_id)
   SELECT start_date,loan_amount,interest,cust_id;


END;

