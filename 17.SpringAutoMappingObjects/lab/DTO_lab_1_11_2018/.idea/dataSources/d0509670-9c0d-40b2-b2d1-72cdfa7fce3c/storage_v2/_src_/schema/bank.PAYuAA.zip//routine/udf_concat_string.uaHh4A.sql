create function udf_concat_string(str1 varchar(30), str2 varchar(30))
  returns varchar(60)
  BEGIN

RETURN CONCAT(REVERSE(str1),REVERSE(str2));

END;

