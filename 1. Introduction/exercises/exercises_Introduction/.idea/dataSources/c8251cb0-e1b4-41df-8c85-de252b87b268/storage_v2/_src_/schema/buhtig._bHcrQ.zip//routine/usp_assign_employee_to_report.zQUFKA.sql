create procedure usp_assign_employee_to_report(IN employee_id int, IN report_id int)
  BEGIN
DECLARE employee_department_id INT DEFAULT (SELECT e.department_id
			FROM employees AS e
			WHERE e.id=employee_id);
DECLARE report_department_id INT DEFAULT (SELECT c.department_id
			FROM reports AS r
			JOIN categories AS c ON c.id=r.category_id
			WHERE r.id=report_id);

 START TRANSACTION;
 
 		 IF employee_department_id!=report_department_id
    
     	THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Employee doesn\'t belong to the appropriate department!';
    
    ROLLBACK;
    ELSE
    
    UPDATE reports AS r
SET r.employee_id=employee_id
WHERE r.id=report_id;

 COMMIT;
    END IF;   

END;

