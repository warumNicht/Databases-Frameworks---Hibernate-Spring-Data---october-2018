create procedure udp_findbyextension(IN extention varchar(30))
  BEGIN


    
SELECT f.id,f.name, CONCAT(f.size,'KB')
FROM files AS f 
WHERE f.name LIKE CONCAT('%',extention);
    

END;

