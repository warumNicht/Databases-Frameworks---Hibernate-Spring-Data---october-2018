create function udf_get_reports_count(employee_id int, status_id int)
  returns int
  BEGIN

RETURN (SELECT COUNT(r.id)
FROM reports AS r 
WHERE r.employee_id=employee_id AND r.status_id=status_id);

END;

