create procedure udp_commit(IN username varchar(30), IN password varchar(30), IN message varchar(255), IN issue_id int)
  BEGIN

 IF NOT EXISTS (SELECT u.id FROM users AS u WHERE u.username=username)  
     THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'No such user!';
    END IF;
    
     IF NOT EXISTS (SELECT u.id FROM users AS u WHERE u.password=`password`)  
     THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Password is incorrect!';
    END IF;
    
    IF NOT EXISTS (SELECT i.id FROM issues AS i WHERE i.id=issue_id)  
     THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'The issue does not exist!';
    END IF;
    
    INSERT INTO commits (message,issue_id,repository_id,contributor_id)
    
    VALUES (message, issue_id, (SELECT i.repository_id FROM issues AS i WHERE i.id=issue_id),
	  (SELECT u.id FROM users AS u WHERE u.password=`password` LIMIT 1) );

    

END;

