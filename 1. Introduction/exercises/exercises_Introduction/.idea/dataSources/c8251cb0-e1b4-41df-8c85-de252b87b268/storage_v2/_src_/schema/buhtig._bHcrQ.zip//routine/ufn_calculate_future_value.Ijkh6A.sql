create function ufn_calculate_future_value(init_sum decimal(20, 2), rate double, years int)
  returns double(20, 11)
  BEGIN
	RETURN init_sum*( POW( (1.0+rate ) , years ));
END;

