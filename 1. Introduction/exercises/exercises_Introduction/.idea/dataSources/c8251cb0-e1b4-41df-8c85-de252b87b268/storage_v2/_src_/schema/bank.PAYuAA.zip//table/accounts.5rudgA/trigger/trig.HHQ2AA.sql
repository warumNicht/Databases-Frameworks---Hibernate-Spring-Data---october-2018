create trigger trig
  before DELETE
  on accounts
  for each row
  BEGIN

DELETE FROM employees_accounts
WHERE account_id=OLD.account_id;

INSERT INTO account_logs(account_id,account_number,start_date,customer_id)
SELECT OLD.account_id,OLD.account_number,OLD.start_date,OLD.customer_id;


END;

