create trigger update_flight_status
  before UPDATE
  on flights
  for each row
  BEGIN

IF OLD.status='Departing' OR OLD.status='Delayed' THEN


INSERT INTO arrived_flights (flight_id,arrival_time,origin,destination,passengers)

VALUES (OLD.flight_id, OLD.arrival_time,
 (SELECT a.airport_name FROM airports AS a WHERE a.airport_id=OLD.origin_airport_id),
 (SELECT a.airport_name FROM airports AS a WHERE a.airport_id=OLD.destination_airport_id),
 (SELECT  COUNT(t.ticket_id)
	FROM flights AS f
	JOIN tickets AS t ON t.flight_id=f.flight_id
	WHERE f.flight_id=OLD.flight_id) );
	
	END IF;


END;

