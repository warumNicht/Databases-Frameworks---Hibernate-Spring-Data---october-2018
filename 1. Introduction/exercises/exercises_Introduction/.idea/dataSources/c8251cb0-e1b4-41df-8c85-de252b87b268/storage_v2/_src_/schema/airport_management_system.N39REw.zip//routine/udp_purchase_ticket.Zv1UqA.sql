create procedure udp_purchase_ticket(IN customer_id int, IN flight_id int, IN ticket_price decimal(8, 2),
                                     IN class       varchar(6), IN seat varchar(5))
  BEGIN

	 IF  (SELECT ca.balance FROM customer_bank_accounts AS ca WHERE ca.customer_id=customer_id)<ticket_price
    THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Insufficient bank account balance for ticket purchase.';
    END IF;
    
    UPDATE customer_bank_accounts AS c
    SET balance=balance-ticket_price
    WHERE c.customer_id=customer_id;
    
    INSERT INTO tickets (price, class, seat,customer_id, flight_id)
    SELECT ticket_price, class, seat, customer_id ,flight_id;

END;

