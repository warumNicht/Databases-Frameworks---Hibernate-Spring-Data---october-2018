create procedure udp_evaluate(IN sub_id int)
  BEGIN
 
 		 IF NOT EXISTS (SELECT s.id FROM submissions AS s WHERE s.id=sub_id)   
     	THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Submission does not exist!';   
    END IF;   

    
    INSERT INTO evaluated_submissions  (id,problem, user,result)
     (SELECT s.id,p.name,u.username, IFNULL(CEIL(p.points/p.tests*s.passed_tests),0)
FROM submissions AS s
JOIN problems AS p ON s.problem_id=p.id
JOIN users AS u ON s.user_id=u.id
WHERE s.id=sub_id);
    

END;

