create procedure udp_login(IN username varchar(30), IN password varchar(30))
  BEGIN

DECLARE user_id INT DEFAULT 0;
DECLARE user_email VARCHAR(50) DEFAULT '';
 
 		 IF NOT EXISTS (SELECT u.id FROM users AS u WHERE u.username=username)   
     	THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Username does not exist!';   
    END IF;   
    
    		 IF NOT EXISTS (SELECT u.id FROM users AS u WHERE u.password=`password`)    
     	THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Password is incorrect!';  
    END IF; 
    
     		 IF EXISTS (SELECT u.id FROM logged_in_users AS u WHERE u.username=username)   
     	THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'User is already logged in!';   
    END IF; 
    
    SET user_id =(SELECT u.id FROM users AS u WHERE u.username=username);
    SET user_email=(SELECT u.email FROM users AS u WHERE u.username=username);
    
    INSERT INTO logged_in_users (id,username,password,email)
    SELECT user_id,username,password,user_email;
    

END;

